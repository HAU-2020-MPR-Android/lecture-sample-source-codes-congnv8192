package com.dennis.sharedpreferencesdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.dennis.sharedpreferencesdemo.models.Friend;
import com.dennis.sharedpreferencesdemo.utils.ObjectSerializer;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String KEY = "name";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), MODE_PRIVATE);

//        String name = sharedPreferences.getString(KEY, null);
//
//        if (name == null) {
//            sharedPreferences.edit().putString("name", "Dennis Nguyen").apply();
//
//            name = "[Guest]";
//        }
//
//        TextView textView = findViewById(R.id.textView);
//        textView.setText(name);

        ArrayList<Friend> friends = new ArrayList<>();
        friends.add(new Friend("Le Phuong Anh"));
        friends.add(new Friend("Trinh Quang Cuong"));


        //
        try {
            sharedPreferences.edit().putString("friends", ObjectSerializer.serialize(friends));


        } catch (IOException e) {
            e.printStackTrace();
        }

        //
        String strFriends = sharedPreferences.getString("friends", null);
        if (strFriends != null) {
            try {
                friends = (ArrayList<Friend>) ObjectSerializer.deserialize(strFriends);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            friends = new ArrayList<>();
        }

    }
}