package com.dennis.friendlist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.dennis.friendlist.models.Note;

public class CreateActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        final Note note = new Note("");

        EditText edtContent = findViewById(R.id.edtContent);
        edtContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String content = editable.toString();

                if (!content.isEmpty()) {
                    note.setContent(editable.toString());

                    if (!MainActivity.notes.contains(note)) {
                        MainActivity.notes.add(note);
                    }

                    MainActivity.noteAdapter.notifyDataSetChanged();
                } else {
                    MainActivity.notes.remove(note);
                }

                // save data

            }
        });
    }
}