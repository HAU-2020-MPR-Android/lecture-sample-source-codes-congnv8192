package com.dennis.friendlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.dennis.friendlist.models.Note;

import org.w3c.dom.Text;

public class UpdateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        Intent intent = getIntent();
        int noteId = intent.getIntExtra("noteId", 0);

        final Note note = MainActivity.notes.get(noteId);

        EditText edtContent = findViewById(R.id.edtContent);
        edtContent.setText(note.getContent());

        edtContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                note.setContent(editable.toString());

                MainActivity.noteAdapter.notifyDataSetChanged();

                // save
            }
        });
    }
}