package com.dennis.friendlist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.dennis.friendlist.adapters.NoteAdapter;
import com.dennis.friendlist.models.Note;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String KEY = "friends";

    public static ArrayList<Note> notes;
    static NoteAdapter noteAdapter;
    SharedPreferences sharedPreferences;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        switch(item.getItemId()) {
            case R.id.addNote:
                Intent intent = new Intent(this, CreateActivity.class);

                startActivity(intent);

                return true;
        }

        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvNotes = findViewById(R.id.rvNotes);

        notes = new ArrayList<>();
        
        // load db
        SQLiteDatabase db = openOrCreateDatabase("mpr", MODE_PRIVATE, null);

//        db.execSQL("CREATE TABLE IF NOT EXISTS newNotes (id INT(3) PRIMARY KEY, content VARCHAR)");


        db.execSQL("UPDATE newNotes SET content='abc' WHERE id=1");


        //        db.execSQL("INSERT INTO newNotes (content) VALUES ('Note example')");

        Cursor cursor = db.rawQuery("SELECT * FROM newNotes WHERE content LIKE '%mpr%' order by id desc limit 3", null);


        int idIndex = cursor.getColumnIndex("id");
        int contentIndex = cursor.getColumnIndex("content");

        cursor.moveToFirst();

        while(cursor != null) {
            int id = cursor.getInt(idIndex);
            String content = cursor.getString(contentIndex);

            Note note = new Note(id, content);
            notes.add(note);

            cursor.moveToNext();
        }

//        notes.add(new Note("Note example"));
        sharedPreferences = getSharedPreferences(getPackageName(), MODE_PRIVATE);

        noteAdapter = new NoteAdapter(notes);
        rvNotes.setAdapter(noteAdapter);
        rvNotes.setLayoutManager(new LinearLayoutManager(this));

    }


}