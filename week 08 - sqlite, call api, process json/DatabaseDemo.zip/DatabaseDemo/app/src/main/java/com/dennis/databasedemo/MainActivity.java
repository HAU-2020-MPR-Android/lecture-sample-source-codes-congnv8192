package com.dennis.databasedemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.AsyncTaskLoader;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try {
            SQLiteDatabase db = this.openOrCreateDatabase("mpr", MODE_PRIVATE, null);

            // DDL
            db.execSQL("CREATE TABLE IF NOT EXISTS notes (" +
                    "id INTEGER," +
                    "content VARCHAR," +
                    "PRIMARY KEY(id AUTOINCREMENT)" +
                    ");"
            );
            db.execSQL("INSERT INTO notes (content) VALUES ('Java is cool.')");
            db.execSQL("INSERT INTO notes (content) VALUES ('MPR is fun.')");

            // DML
            Cursor cursor = db.rawQuery("SELECT * FROM notes", null);
            int contentIndex = cursor.getColumnIndex("content");
            cursor.moveToFirst();

            while (cursor != null) {
                String content = cursor.getString(contentIndex);

                cursor.moveToNext();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}