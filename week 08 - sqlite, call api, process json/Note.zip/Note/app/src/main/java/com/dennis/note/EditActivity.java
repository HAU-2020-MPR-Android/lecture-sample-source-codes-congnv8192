package com.dennis.note;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import com.dennis.note.models.Note;

public class EditActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        EditText text = findViewById(R.id.text);

        Intent intent = getIntent();
        int position = intent.getIntExtra("position", -1);

        if (position != -1) {
            Note note = MainActivity.notes.get(position);
            text.setText(note.getText());
        }
    }
}