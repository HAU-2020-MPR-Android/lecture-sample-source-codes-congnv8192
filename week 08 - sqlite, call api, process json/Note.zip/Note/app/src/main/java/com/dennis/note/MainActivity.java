package com.dennis.note;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.dennis.note.adapters.NoteAdapter;
import com.dennis.note.models.Note;
import com.dennis.note.utils.ObjectSerializer;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static ArrayList<Note> notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try {
            notes = loadNotes();
        } catch (IOException e) {
            e.printStackTrace();
        }


        NoteAdapter noteAdapter = new NoteAdapter(notes);
        RecyclerView rvNotes = findViewById(R.id.rvNotes);
        rvNotes.setAdapter(noteAdapter);
        rvNotes.setLayoutManager(new LinearLayoutManager(this));
    }

    private ArrayList<Note> loadNotes() throws IOException {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String notes = sharedPreferences.getString("notes", null);

        if (notes != null) {
            return (ArrayList<Note>) ObjectSerializer.deserialize(notes);
        } else {
            ArrayList<Note> result = new ArrayList<>();
            result.add(new Note("Example note"));

            return result;
        }
    }
}