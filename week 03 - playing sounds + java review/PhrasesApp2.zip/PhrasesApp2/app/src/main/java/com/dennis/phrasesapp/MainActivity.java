package com.dennis.phrasesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void handleClick(View view) {
        int id = view.getId();

        String ourId = view.getResources().getResourceEntryName(id);
        int audio = getResources().getIdentifier(ourId, "raw", getPackageName());

        MediaPlayer mediaPlayer = MediaPlayer.create(this, audio);
        mediaPlayer.start();
    }
}